[![Build Status](https://vielab-build1.cisco.com/api/badges/danischm/aac-cs-demo/status.svg)](https://vielab-build1.cisco.com/danischm/aac-cs-demo)

# ACI as Code - Demo

A sample ACI inventory to demonstrate *ACI as Code* capabilities including NAE integration.

## Documentation

Documentation is available [here](https://aac.cisco.com).
